﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SampleWebApplication.Models
{
    public class Class1
    {
        public int Visits { get; set; }
        public String PageName { get; set; }
        public String AccessDate { get; set; }
    }
}