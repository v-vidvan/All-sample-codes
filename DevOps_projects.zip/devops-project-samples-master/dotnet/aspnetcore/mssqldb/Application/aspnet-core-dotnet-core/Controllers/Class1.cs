﻿namespace aspnet_core_dotnet_core.Controllers
{
    public class Class1
    {
        public int Visits { get; set; }
        public string PageName { get; set; }
        public string AccessDate { get; set; }

    }
}