using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace aspnet_core_dotnet_core.UnitTests
{
    [TestClass]
    public class SampleUnitTests
    {
        [TestMethod]
        public void SampleTest1()
        {
            Assert.AreEqual(1, 1);
        }

        [TestMethod]
        public void SampleTest2()
        {
            Assert.AreEqual(1, 1);
        }

        [TestMethod]
        public void SampleTest3()
        {
            Assert.AreEqual(1, 1);
        }
    }
}
